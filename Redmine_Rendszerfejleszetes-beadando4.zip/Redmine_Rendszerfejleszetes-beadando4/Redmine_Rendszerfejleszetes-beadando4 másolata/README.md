# Rendszerfejlesztes beadandó

# Beüzemelés
- Telepítsük a [XAMPP-ot](https://www.apachefriends.org/download.html) és a [Composer-t](https://getcomposer.org/download/)
- Másoljuk be a XAMPP htdocs mappájába a projektet (alapértelmezetten C:/xampp/htdocs)
- Egy terminálban a projekt mappáján belül futtassuk le a `composer install` commandot
- Ugyanitt a websocket elindításához adjuk ki a `php php\websocket.php` parancsot (task feltöltésére és törlésére figyel)
- Indítsuk el a XAMPP-ot, majd azon belül az Apache és MySQL szervereket (ha létezik töröljük a régebbi adatbázist)
- Tetszőleges böngészőben keressük fel a localhost/(projekt_mappa_nev)/login.php címet
- admin login: admin@admin.hu : admin ; manager: heller.benedek@gmail.com : beni123 , ferencz.kristof@gmail.com : kristof123
